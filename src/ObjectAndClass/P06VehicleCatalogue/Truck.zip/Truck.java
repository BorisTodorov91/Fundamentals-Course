package ObjectAndClass.P06VehicleCatalogue;

import java.util.ArrayList;
import java.util.List;

public class Truck extends Vehicle {

    public Truck(String typeOfVehicle, String model, String color, double horsePower) {
        super("Truck", model, color, horsePower);
    }


}