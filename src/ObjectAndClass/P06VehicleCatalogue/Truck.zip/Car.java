package ObjectAndClass.P06VehicleCatalogue;

public class Car extends Vehicle{

    public Car(String typeOfVehicle, String model, String color, double horsePower) {
        super("Car", model, color, horsePower);
    }
}
